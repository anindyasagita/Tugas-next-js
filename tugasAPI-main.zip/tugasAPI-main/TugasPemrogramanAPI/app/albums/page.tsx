const albums = () => {
    return (
        <div>ALBUM PAGE</div>
    )
}

export default albums
